package com.example.eBookStoreAPIGateWay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreApiGateWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
