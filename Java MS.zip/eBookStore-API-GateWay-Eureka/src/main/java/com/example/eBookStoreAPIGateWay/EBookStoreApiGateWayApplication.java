package com.example.eBookStoreAPIGateWay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

import com.example.eBookStoreAPIGateWay.filters.ErrorFilter;
import com.example.eBookStoreAPIGateWay.filters.PostFilter;
import com.example.eBookStoreAPIGateWay.filters.PreFilter;
import com.example.eBookStoreAPIGateWay.filters.RouteFilter;

@EnableZuulProxy
@SpringBootApplication
public class EBookStoreApiGateWayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreApiGateWayApplication.class, args);
	}
	@Bean
	public PreFilter getPreFilter()
	{
		return new PreFilter();
	}
	@Bean
	public PostFilter getPostFilter()
	{
		return new PostFilter();
	}
	@Bean
	public RouteFilter getRouteFilter()
	{
		return new RouteFilter();
	}
	
	@Bean
	public ErrorFilter getErrorFilter()
	{
		return new ErrorFilter();
	}

}
