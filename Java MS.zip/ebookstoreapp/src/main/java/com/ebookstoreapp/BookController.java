package com.ebookstoreapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class BookController{
	
@Autowired
BookStoreService bookservice;
	
@PostMapping("/books")
public Book addBook(@RequestBody Book book) {
    return bookservice.addBook(book);
}

// Update a book
/*@PutMapping("/books")
public Book updateBook(@RequestBody Book book) {
    return bookservice.updateBook(book);
}*/

// Get all books
@GetMapping("/books")
public List<Book> getAllBooks() {
    return bookservice.getAll();
}

// Get a book by its ID
@GetMapping("/books/{id}")
public Book getBookById(@PathVariable("id")int id) {
	return bookservice.getbyid(id);
}

// Delete a book by its ID
@DeleteMapping("/{book_id}")
public void deleteBookById(@PathVariable int book_id) {
	bookservice.deletebyid(book_id);
}
//Get books by title
@GetMapping("/title/{book_title}")
public Book getBooksByTitle(@PathVariable String book_title) {
    return bookservice.getbytitle(book_title);
}

// Get books by publisher
@GetMapping("/publisher/{book_publisher}")
public List<Book> getBooksByPublisher(@PathVariable String book_publisher) {
    return bookservice.getbypublisher(book_publisher);
}

// Get books by year
@GetMapping("/{book_year}")
public List<Book> getBooksByYear(@RequestParam("year") int year) {
    return bookservice.getbyyear(year);
}
}

