package com.ebookstoreapp;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EbookRepository extends JpaRepository<Book, Integer> {

	Book findBybookTitle(String bookTitle);
	List<Book> findBybookPublisher(String bookPublisher);
	List<Book> findBybookYear(int bookYear);
}
