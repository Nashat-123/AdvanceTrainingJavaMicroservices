package com.ebookstoreapp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookStoreService {

	@Autowired
	EbookRepository ebook;
	
	public Book addBook(Book book) {
		return ebook.save(book);
	}
	
	public List<Book> getAll(){
		return ebook.findAll();
	}
	
	     
	public Book getbyid(int id) {
		return ebook.findById(id).get();
	}
	
	public Book getbytitle(String title) {
       return ebook.findBybookTitle(title);
	}
	
	public List<Book> getbypublisher(String publisher) {
		return ebook.findBybookPublisher(publisher);
	}
	public List<Book> getbyyear(int year) {
		return ebook.findBybookYear(year);
	}
	/*public Book updateBook(Book updBook) {
	    int id = updBook.getId();
	    Optional<Book> optionalBook = ebook.findById(id);
	    
	    if (!optionalBook.isPresent()) {
	        // Handle the error (e.g., throw an exception or return null)
	        throw new RuntimeException("Book not found with ID: " + id);
	    }

	    Book book = optionalBook.get();

	    if (updBook.getBookTitle() != null) {
	        book.setBookTitle(updBook.getBookTitle());
	    }

	    if (updBook.getBookPublisher() != null) {
	        book.setBookPublisher(updBook.getBookPublisher());
	    }

	    if (updBook.getBookNumberOfPages() != 0) {
	        book.setBookNumberOfPages(updBook.getBookNumberOfPages());
	    }

	    if (updBook.getBookIsbn() != null) {
	        book.setBookIsbn(updBook.getBookIsbn());
	    }
       if(updBook.getBookYear()!=0) {
    	   book.setBookYear(updBook.getBookYear());
       }
	    return ebook.save(book);
	}*/

	
	public void deletebyid(int id) {
		ebook.deleteById(id);
		
	}
	
	
}
